# Web 自动化测试（Java + Selenium + JUnit 5）

作者：彭玢毓 5120244700　班级：003　实验：狂神系统测试

## 测试对象

狂神社区（http://localhost:8080，账号 admin / 123456），覆盖「登录 → 进入问答 → 发布问题 → 发布成功验证」完整业务流程。

## 文件说明

- `pom.xml` —— Maven 工程配置（selenium-java 4.18.1 + junit-jupiter 5.10.2，与评分工程一致）
- `src/test/java/demo/KuangCommunityQuestionTest.java` —— 用例本体（1 个用例串完整流程）
- `src/test/java/demo/EdgeDriverResolver.java` —— Edge 驱动版本兜底工具类
- `src/main/java/demo/Calculator.java` —— 工程脚手架（保留原结构，补充了 @author 注释）
- `screenshots/` —— 一次完整执行的 6 张过程截图（01 首页 → 06 发布成功）

## 运行方法

前置条件：被测系统已在本地 8080 端口启动；本机装有 Edge 浏览器。

```bash
mvn test
```

无头模式默认开启（便于命令行执行），想看浏览器实际操作加：

```bash
mvn test -Dwebui.headless=false
```

每次执行会在 `target/screenshots/` 重新生成 01~06 六张截图，并在问答列表里真实发布一条「自动化测试-时间戳」标题的帖子。

## 关键实现点

1. 定位方式混用 `By.cssSelector / By.name / By.id / By.xpath` 四种；等待全部用 `WebDriverWait` 显式等待，没有 `Thread.sleep`。
2. 断言 5 处：登录按钮文案、密码输入框 placeholder、"记住密码"勾选状态、发布后列表第一条标题与新标题一致等。
3. 编辑详情框的坑：页面上的 `textarea#content` 是 `display:none` 的，真实可输入的是 editormd 生成的 `.CodeMirror textarea`，需要先点 `.CodeMirror` 获取焦点再输入，失败时兜底走 JS 赋值。
4. 驱动版本兜底：Edge 会自动升级导致驱动不匹配（如目录里是 157 实际跑 156）。`EdgeDriverResolver` 的策略是——优先用工程 `drivers/` 下的本地驱动，会话创建失败时从报错信息里解析真实浏览器版本，再从 npmmirror 镜像下载匹配版本的驱动。所以即使不带 24MB 的驱动二进制，任何 Edge 版本都能跑。
