package demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * 狂神社区 Web 自动化测试：登录 → 进入问答 → 发布问题。
 *
 * <p>被测地址：{@code http://localhost:8080/}，账号 admin / 123456（实验说明给出）。</p>
 *
 * <p>测试流程（对应实验要求步骤 1~8）：
 * 进入首页点击“登录” → 输入用户名 → 输入密码 → 勾选“记住密码” → 点击“登录”跳转首页
 * → 点击“问答” → 点击“发布问题” → 输入问题标题 → 输入问题详情 → 点击“发布问题”完成发布。</p>
 *
 * <p>技术要点：
 * <ul>
 *   <li>JUnit 5 编写测试用例，使用 assertTrue / assertEquals 断言；</li>
 *   <li>声明 {@code driver} 变量控制浏览器，用例执行完毕在 @AfterEach 中 quit 释放；</li>
 *   <li>所有元素查找统一走显式等待 {@link WebDriverWait}，脚本里不出现 Thread.sleep；</li>
 *   <li>元素定位使用 By.name、By.id、By.cssSelector、By.xpath 四种方式；</li>
 *   <li>关键步骤自动截图，保存到 {@code target/screenshots/}，可直接作为实验报告的执行证据。</li>
 * </ul></p>
 */
public class KuangCommunityQuestionTest {

    /** 被测系统首页地址 */
    private static final String BASE_URL = "http://localhost:8080/";

    /** 登录用户名（实验说明中的管理员账号） */
    private static final String USERNAME = "admin";

    /** 登录密码 */
    private static final String PASSWORD = "123456";

    /** 显式等待最长超时时间：本地系统响应很快，10 秒足够，超时即为真实缺陷 */
    private static final Duration WAIT_TIMEOUT = Duration.ofSeconds(10);

    /** 是否无头运行：默认开启便于命令行执行，加 -Dwebui.headless=false 可以看到浏览器实际操作过程 */
    private static final boolean HEADLESS =
            !"false".equalsIgnoreCase(System.getProperty("webui.headless", "true"));

    /** driver 变量：控制浏览器 */
    private WebDriver driver;

    /** 显式等待对象：所有元素查找都通过它等待元素出现，替代固定休眠 */
    private WebDriverWait wait;

    /** 每个用例执行前：启动浏览器并初始化显式等待 */
    @BeforeEach
    void setUp() {
        driver = createDriver();
        wait = new WebDriverWait(driver, WAIT_TIMEOUT);
    }

    /** 每个用例执行后：关闭浏览器，释放资源 */
    @AfterEach
    void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    /**
     * 创建浏览器驱动。
     *
     * <p>本机没有单独安装 Chrome，统一使用 Windows 自带的 Edge；驱动通过 System.setProperty
     * 指向工程内的本地 exe，离线环境下也能跑，不依赖 Selenium Manager 联网下载。</p>
     *
     * <p>Edge 会自动升级，驱动和浏览器大版本一旦对不上，浏览器启动就会失败。处理办法是：
     * 先把手上的驱动逐个试一遍，全部失败时从报错里读出浏览器真实版本，去国内镜像补一个
     * 匹配版本的驱动再启动（详见 {@link EdgeDriverResolver} 的注释）。</p>
     */
    private WebDriver createDriver() {
        Path projectDir = Path.of(System.getProperty("user.dir"));
        EdgeOptions options = buildEdgeOptions();

        SessionNotCreatedException failure = null;
        for (Path driverExe : EdgeDriverResolver.availableDrivers(projectDir)) {
            System.setProperty("webdriver.edge.driver", driverExe.toAbsolutePath().toString());
            try {
                return new EdgeDriver(options);
            } catch (SessionNotCreatedException e) {
                // 该驱动与当前浏览器版本不匹配，换下一个候选继续试
                failure = e;
                System.out.println("[驱动] 版本不匹配，尝试下一个：" + driverExe.getFileName());
            }
        }

        String browserVersion = EdgeDriverResolver.browserVersionOf(failure);
        Path downloaded = browserVersion == null
                ? null : EdgeDriverResolver.download(browserVersion, projectDir);
        if (downloaded == null) {
            if (failure == null) {
                throw new IllegalStateException(
                        "未找到可用的 Edge 驱动，请确认 drivers/msedgedriver.exe 存在，或联网后重试");
            }
            throw failure;
        }
        System.setProperty("webdriver.edge.driver", downloaded.toAbsolutePath().toString());
        return new EdgeDriver(options);
    }

    /** 组装 Edge 启动参数：固定窗口大小 + 可选无头模式。 */
    private EdgeOptions buildEdgeOptions() {
        EdgeOptions options = new EdgeOptions();
        // 固定窗口大小：窗口太窄时右侧栏会被折叠，页面上就找不到“发布问题”按钮
        options.addArguments("--window-size=1440,1000");
        options.addArguments("--disable-gpu");
        if (HEADLESS) {
            options.addArguments("--headless=new");
        }
        return options;
    }

    /**
     * 测试用例：登录狂神社区后发布一条问答，并校验发布结果。
     *
     * <p>标题带上时间戳，保证反复执行不会和上一次的问题重名，
     * 也方便在问答列表里确认“刚发布的就是这一条”。</p>
     */
    @Test
    @DisplayName("狂神社区：登录并发布一条问答")
    void shouldLoginAndPublishQuestion() {
        String title = "自动化测试-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("MMddHHmmss"));
        String content = "这是 Web 自动化测试发布的问题详情。";

        // 步骤 1：进入系统首页，点击导航栏“登录”按钮（By.cssSelector 定位）
        driver.get(BASE_URL);
        WebElement loginEntry = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("a.btn.btn-sm.btn-primary")));
        assertEquals("登录", loginEntry.getText().trim(), "首页导航栏按钮文字应是“登录”");
        screenshot("01-home");
        loginEntry.click();

        // 步骤 2：点击用户名输入框，输入用户名（By.name 定位）
        WebElement usernameInput = waitAndType(By.name("username"), USERNAME);
        assertEquals("用户名", usernameInput.getAttribute("placeholder"), "应定位到用户名输入框");

        // 步骤 3：点击密码输入框，输入密码（By.name 定位）
        waitAndType(By.name("password"), PASSWORD);

        // 步骤 4：点击“记住密码”复选框（By.name 定位）
        WebElement rememberBox = wait.until(ExpectedConditions.elementToBeClickable(By.name("remember")));
        rememberBox.click();
        assertTrue(rememberBox.isSelected(), "点击后“记住密码”应处于勾选状态");
        screenshot("02-login-filled");

        // 步骤 5：点击“登录”，成功跳转至首页（By.cssSelector 定位）
        waitAndClick(By.cssSelector("button[type='submit']"));
        wait.until(ExpectedConditions.urlContains("/index"));
        WebElement userSpan = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//span[normalize-space()='" + USERNAME + "']")));
        assertEquals(USERNAME, userSpan.getText().trim(), "登录成功后导航栏应显示当前用户名");
        screenshot("03-index-after-login");

        // 步骤 6：点击导航栏“问答”（By.xpath 定位）
        waitAndClick(By.xpath("//a[@href='/question' and contains(normalize-space(),'问答')]"));
        wait.until(ExpectedConditions.urlContains("/question"));
        screenshot("04-question-list");

        // 步骤 7：点击页面右侧“发布问题”按钮，进入编辑页面（By.xpath 定位）
        waitAndClick(By.xpath("//a[@href='/question/write']"));
        wait.until(ExpectedConditions.urlContains("/question/write"));

        // 步骤 8：点击问题标题输入框，输入问题标题（By.id 定位，该输入框 id 为 firstName）
        WebElement titleInput = waitAndType(By.id("firstName"), title);
        assertEquals(title, titleInput.getAttribute("value"), "标题输入框内容应与输入一致");

        // 步骤 9：点击问题详情输入框，输入问题详情
        typeQuestionContent(content);
        screenshot("05-write-question");

        // 步骤 10：点击“发布问题”按钮，成功发布问题
        waitAndClick(By.xpath("//button[@type='submit' and contains(normalize-space(),'发布问题')]"));
        // 发布成功后服务端返回 302 跳回问答列表，这里等待离开编辑页
        wait.until(ExpectedConditions.not(ExpectedConditions.urlContains("/question/write")));
        WebElement newestQuestion = wait.until(ExpectedConditions.presenceOfElementLocated(
                By.cssSelector("a[href^='/question/read/']")));
        assertEquals(title, newestQuestion.getText().trim(), "问答列表第一条应是刚发布的问题");
        screenshot("06-question-published");

        System.out.println("[用例通过] 已发布问题：" + title);
    }

    /**
     * 显式等待元素可点击后点击它。
     *
     * <p>统一走这里的好处：页面还在渲染时点击会抛 ElementNotInteractableException，
     * 用显式等待可以让脚本等元素真正可交互，而不是靠 Thread.sleep 猜时间。</p>
     *
     * @param locator 元素定位方式
     */
    private void waitAndClick(By locator) {
        wait.until(ExpectedConditions.elementToBeClickable(locator)).click();
    }

    /**
     * 显式等待元素可见，然后点击、清空并输入文本。
     *
     * @param locator 元素定位方式
     * @param text    要输入的文本
     * @return 输入过的元素，方便调用方继续断言
     */
    private WebElement waitAndType(By locator, String text) {
        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
        element.click();
        element.clear();
        element.sendKeys(text);
        return element;
    }

    /**
     * 在 editormd 富文本编辑器中输入问题详情。
     *
     * <p>问题详情看着是一个大方框，其实是 editormd 基于 CodeMirror 渲染出来的：
     * 表单真正提交的 {@code textarea#content} 被 {@code display:none} 隐藏，
     * 直接对它 sendKeys 会抛 ElementNotInteractableException。所以先点击可见的
     * {@code .CodeMirror} 让编辑器获得焦点，再向 CodeMirror 内部的隐藏 textarea 输入。
     * 如果该浏览器的焦点处理仍然失败，则退一步用 JS 调用编辑器接口赋值，保证用例不中断。</p>
     *
     * @param content 问题详情文本
     */
    private void typeQuestionContent(String content) {
        WebElement editor = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".CodeMirror")));
        editor.click();
        WebElement editorInput = wait.until(ExpectedConditions.presenceOfElementLocated(
                By.cssSelector(".CodeMirror textarea")));
        try {
            editorInput.sendKeys(content);
        } catch (RuntimeException e) {
            System.out.println("[提示] 编辑器无法直接输入，改用 JS 赋值：" + e.getClass().getSimpleName());
            ((JavascriptExecutor) driver)
                    .executeScript("arguments[0].CodeMirror.setValue(arguments[1]);", editor, content);
        }
    }

    /**
     * 截取当前页面，保存到 {@code target/screenshots/<name>.png}。
     *
     * <p>截图只是为了给实验报告留执行证据，失败时只打印提示，不影响用例结果。</p>
     *
     * @param name 截图文件名（不带扩展名）
     */
    private void screenshot(String name) {
        try {
            Path dir = Path.of(System.getProperty("user.dir"), "target", "screenshots");
            Files.createDirectories(dir);
            Files.write(dir.resolve(name + ".png"),
                    ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES));
        } catch (IOException e) {
            System.out.println("[截图] 保存失败：" + name + " -> " + e.getMessage());
        }
    }

    /*
     * 自带入口方法 Main（按实验要求注释保留，不删除，方便统计代码量）。
     *
     * JUnit 5 不支持 JUnitCore.runClasses 这种 JUnit 4 的运行方式，不通过 Maven 手工运行时可这样启动：
     *
     * public static void main(String[] args) {
     *     // 需要 junit-platform-console-standalone-1.10.2.jar，命令：
     *     // java -jar junit-platform-console-standalone-1.10.2.jar -c demo.KuangCommunityQuestionTest
     *     System.out.println("Main 入口已保留，测试统一交给 JUnit 5 / Maven Surefire 执行。");
     * }
     */
}
