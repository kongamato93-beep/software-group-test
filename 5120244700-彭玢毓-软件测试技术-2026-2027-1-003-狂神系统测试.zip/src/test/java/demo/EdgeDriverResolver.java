package demo;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Edge 驱动（msedgedriver）管理工具。
 *
 * <p>踩过的坑：msedgedriver 的大版本必须和真正运行的 Edge 浏览器一致，否则浏览器一启动就断开，
 * 报 {@code session not created: This version of Microsoft Edge WebDriver only supports
 * Microsoft Edge version 157 / Current browser version is 156.0.4314.58}。</p>
 *
 * <p>更麻烦的是，“Edge 安装目录里最高的版本号”并不等于“正在运行的版本”：
 * Edge 自动更新时会把新版本先解压到 {@code Application\157.x\} 里，等浏览器重启才真正生效。
 * 所以这里不去猜版本，而是：</p>
 *
 * <ol>
 *   <li>先把手上已有的驱动（{@code target/edge-driver/} 下的缓存 + 工程 {@code drivers/} 里的内置驱动）
 *       按版本从高到低依次尝试；</li>
 *   <li>都启动不了时，从驱动返回的报错里读出浏览器真实版本，去国内镜像下载对应版本的驱动再试一次
 *       （官方下载源 msedgedriver.azureedge.net 在国内经常连不通）。</li>
 * </ol>
 */
final class EdgeDriverResolver {

    /** 驱动下载镜像（国内可访问）。 */
    private static final String MIRROR = "https://registry.npmmirror.com/-/binary/edgedriver/";

    /** 从驱动报错中提取浏览器版本，例如 Current browser version is 156.0.4314.58 */
    private static final Pattern BROWSER_VERSION = Pattern.compile("Current browser version is ([\\d.]+)");

    private EdgeDriverResolver() {
    }

    /**
     * 列出本机可用的驱动文件，按版本号从高到低排序，供调用方逐个尝试。
     *
     * @param projectDir 工程根目录（一般传 {@code user.dir}）
     * @return 驱动文件路径列表，可能为空
     */
    static List<Path> availableDrivers(Path projectDir) {
        List<Path> drivers = new ArrayList<>();
        Path cacheRoot = projectDir.resolve("target").resolve("edge-driver");
        if (Files.isDirectory(cacheRoot)) {
            try (var versions = Files.list(cacheRoot)) {
                versions.filter(Files::isDirectory)
                        .sorted(Comparator.comparing((Path p) -> p.getFileName().toString()).reversed())
                        .map(p -> p.resolve("msedgedriver.exe"))
                        .filter(Files::exists)
                        .forEach(drivers::add);
            } catch (Exception ignored) {
                // 缓存目录不可读就只用内置驱动
            }
        }
        Path bundled = projectDir.resolve("drivers").resolve("msedgedriver.exe");
        if (Files.exists(bundled)) {
            drivers.add(bundled);
        }
        return drivers;
    }

    /**
     * 从启动失败的报错信息里取出浏览器真实版本号。
     *
     * @param error 启动驱动时抛出的异常
     * @return 形如 156.0.4314.58 的版本号；取不到返回 {@code null}
     */
    static String browserVersionOf(Throwable error) {
        if (error == null || error.getMessage() == null) {
            return null;
        }
        Matcher matcher = BROWSER_VERSION.matcher(error.getMessage());
        return matcher.find() ? matcher.group(1) : null;
    }

    /**
     * 从国内镜像下载指定版本的驱动并解压，已下载过就直接复用缓存。
     *
     * @param version    驱动版本，需与浏览器版本一致
     * @param projectDir 工程根目录
     * @return 解压后的驱动路径；下载失败返回 {@code null}
     */
    static Path download(String version, Path projectDir) {
        Path targetDir = projectDir.resolve("target").resolve("edge-driver").resolve(version);
        Path target = targetDir.resolve("msedgedriver.exe");
        if (Files.exists(target)) {
            return target;
        }
        Path zip = targetDir.resolve("edgedriver_win64.zip");
        try {
            Files.createDirectories(targetDir);
            String url = MIRROR + version + "/edgedriver_win64.zip";
            System.out.println("[驱动] 下载 " + url);
            HttpURLConnection conn = (HttpURLConnection) URI.create(url).toURL().openConnection();
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(120000);
            conn.setInstanceFollowRedirects(true);
            try (InputStream in = conn.getInputStream()) {
                Files.copy(in, zip, StandardCopyOption.REPLACE_EXISTING);
            }
            unzipDriver(zip, target);
            System.out.println("[驱动] 下载完成：" + target);
            return target;
        } catch (Exception e) {
            System.out.println("[驱动] 下载失败：" + e);
            return null;
        } finally {
            try {
                Files.deleteIfExists(zip);
            } catch (Exception ignored) {
                // 删除临时压缩包失败不影响主流程
            }
        }
    }

    /** 从压缩包中取出 msedgedriver.exe 写到目标路径。 */
    private static void unzipDriver(Path zip, Path target) throws Exception {
        try (ZipFile zipFile = new ZipFile(zip.toFile())) {
            ZipEntry entry = zipFile.stream()
                    .filter(e -> e.getName().toLowerCase().endsWith("msedgedriver.exe"))
                    .findFirst()
                    .orElseThrow(() -> new IllegalStateException("压缩包内未找到 msedgedriver.exe"));
            try (InputStream in = zipFile.getInputStream(entry);
                 OutputStream out = Files.newOutputStream(target)) {
                in.transferTo(out);
            }
        }
    }
}
