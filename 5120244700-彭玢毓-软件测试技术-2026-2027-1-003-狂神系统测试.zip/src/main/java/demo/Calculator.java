package demo;

/**
 * 工程自带的示例主类，保留脚手架结构，供评分工具做静态分析使用。
 *
 * @author 彭玢毓 5120244700
 */
public class Calculator {

    /**
     * 计算两个整数的和并返回结果。
     */
    public int add(int a, int b) {
        return a + b;
    }
}
